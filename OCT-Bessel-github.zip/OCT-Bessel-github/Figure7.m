%% OCT Bessel Stalls - Figure 7
clearvars;
close all;

mice = {'Mouse008','Mouse009','Mouse010','Mouse011','Mouse012','Mouse013','Mouse014','Mouse015',};
labels = {'Baseline','Day 2','Week 1','Week 2','Week 4'};
short_labels = {'BL','D2','W1','W2','W4'};
cmap = hot;
cmap = cmap([1,52,103,155,206],:);
nframes = 80;
t = 0:7.5:600;
t = (0:nframes-1) * 7.5 / 60;

%% Load data
% Total number of capillaries (rows = mice, columns = timepoints)
ncapstot = [186 119	185	216	219;
            214	101	223	187	198;
            221	163	190	205	170;
            239	207	214	220	224;
            156	223	205	230	233;
            203	186	161	190	194;
            130	136	141	165	167;
            138	101	107	176	187];

dataDir = fullfile(pwd,'\Data\Stroke_OCT_Stallograms\');
for ix = 1:length(labels)
    cum_inc_traces = NaN(length(mice),nframes);
    for jx = 1:length(mice)
        dataFiles = dir([dataDir '\' mice{jx} '_' short_labels{ix} '.mat']);
        load(fullfile(dataFiles(1).folder,dataFiles(1).name))
        total = ncapstot(jx,ix);
        for kx = 1:size(StallingMatrix,1)
            cum_inc_traces(jx,:) = 100 * sum(cumsum(StallingMatrix,2) > 0,1) / total;
        end
    end
    
    % double exp fit
    doubleexp = fittype('A*(1 - exp(-x/B)) + C*(1 - exp(-x/D)) + E', 'independent', 'x', 'coefficients', {'A', 'B', 'C','D','E'}); 
    w = 1./(std(cum_inc_traces,1)').^2; % calculate weights for fit   
    if exist('w','var') % if std var included in input, use it for weights in fit model        
        doubleexpfitmean = fit(t', mean(cum_inc_traces,1)', doubleexp, 'Start', [1 10 1 90 1], 'Lower', [0 0 0 0 0], 'Upper', [100 Inf 100 Inf 100], 'Weights', w);    
    else        
        doubleexpfitmean = fit(t', mean(cum_inc_traces,1)', doubleexp, 'Start', [1 10 1 90 1], 'Lower', [0 0 0 0 0], 'Upper', [100 Inf 100 Inf 100]);    
    end

    % Mean
    figure(71)
    hold on
    ax(ix) = plot(t,mean(cum_inc_traces,1),'Color',cmap(ix,:),'LineWidth',2);
    tfill = [t, fliplr(t)];
    yfill = [mean(cum_inc_traces,1) - std(cum_inc_traces,1) / sqrt(length(mice)), fliplr(mean(cum_inc_traces,1) + std(cum_inc_traces,1) / sqrt(length(mice)))];
    fill(tfill, yfill,[cmap(ix,:)],'FaceAlpha', 0.1,'EdgeColor','none');
    plot(t,feval(doubleexpfitmean,t),'--','Color',[cmap(ix,:) 0.8],'LineWidth',1)
end
figure(71)
ylabel('Incidence %')
ylim([0 Inf])
xlabel('Time (minutes)')
legend(ax,labels,'location','best')
grid on
set(findall(gcf,'-property','FontSize'),'FontSize',16)

f = figure(71);
f.Position = [100 100 500 700];

%% Calculate stats
tPerFrame = 7.5;
rate = [];
durMean = [];
durStd = [];
cumIncidence = [];
rateFile = []; % stall rate averaged over file
durFile = []; % stall duration averaged over file
iCap1 = [];
stallDuration = [];

dataDir = fullfile(pwd,'\Data\Stroke_OCT_Stallograms\');
for ix = 1:length(mice)
    for jx = 1:length(labels)
        dataFiles = dir([dataDir '\' mice{ix} '_' short_labels{jx} '.mat']);
        load(fullfile(dataFiles(1).folder,dataFiles(1).name))

        if ix == 1
            stallDuration(jx).d = [];
            iCap1(jx).d = 0;
            rate(jx).d = [];
        end
        rateFile(ix,jx).d = [];
        durFile(ix,jx).d = [];
        iCapFile = 0;

        nCaps = size(StallingMatrix,1);
        nFrames = size(StallingMatrix,2);
        cumIncidenceMatrix = StallingMatrix;
        for iCap = 1:nCaps
            iRise = find(diff([0 StallingMatrix(iCap,:)])==1)';
            iFall = find(diff([StallingMatrix(iCap,:) 0])==-1)' + 1;
            durStall = (iFall - iRise) * tPerFrame;
            stallDuration(jx).d = [stallDuration(jx).d; (iFall(2:end)-iRise(2:end))*tPerFrame];
            if ~isempty(iRise)
                cumIncidenceMatrix(iCap,iRise(1):end) = 1;

                iCap1(jx).d = iCap1(jx).d + 1;
                rate(jx).d(iCap1(jx).d,1) = length(iRise) * 60 / (nFrames * tPerFrame);
                durMean(iCap1(jx).d,1) = mean(durStall);
                durStd(iCap1(jx).d,1) = std(durStall);

                iCapFile = iCapFile + 1;
                rateFile(ix,jx).d(iCapFile) = length(iRise) * 60 / (nFrames * tPerFrame);
                durFile(ix,jx).d(iCapFile).d = (iFall(2:end)-iRise(2:end))*tPerFrame;
            end
        end
        cumIncidence(:,jx,ix) = sum(cumIncidenceMatrix,1)';%/dataOCTStroke(iFile).nCaps;
    end
end

%% Duration distribution with Std Err
figure(72)

% histogram
n=[];
for jx=1:length(labels)
    [n(jx,:),x] = hist(stallDuration(jx).d,[3.75:7.5:240]);
end

subplot(1,2,1)
hb=bar(x,n','EdgeColor','none');
for jx = 1:length(hb)
    hb(jx).FaceColor = cmap(jx,:);
end
set(gca,'fontsize',16,'xtick',7.5:7.5:60)
xlim([0 60])
xlabel('Duration (seconds)')
title('Histogram')
grid on
legend(labels,'location','best')

% normalized cumulative sum
n=[];
for ix = 1:length(labels)
    for jx = 1:length(mice)
        durs = [];
        for kx = 1:length(durFile(jx,ix).d)
            durs = [durs; durFile(jx,ix).d(kx).d];
        end
        [n(jx,:,ix),x] = hist(durs,[3.75:7.5:240]);
        n(jx,:,ix) = n(jx,:,ix) / length(durs);
        nCumsum(jx,:,ix) = cumsum(n(jx,:,ix));
    end
end
nCumsumMean = squeeze(mean(nCumsum,1));
nCumsumStdErr = squeeze(std(nCumsum,[],1) / sqrt(length(mice)));

subplot(1,2,2)
hold on
for jx = 1:length(labels)
    er = errorbar(x,nCumsumMean(:,jx),-nCumsumStdErr(:,jx),+nCumsumStdErr(:,jx),'.');    
    er.Color = cmap(jx,:);                            
    er.LineStyle = 'none';  
    plot(x,nCumsumMean(:,jx),'.','markersize',16,'Color',cmap(jx,:));
end
xlim([0 60])
set(gca,'fontsize',16,'xtick',7.5:7.5:60)
xlabel('Duration (seconds)')
title('Norm. Cum. Sum')
grid on
legend(labels,'location','best')

%% Rate distribution with Std Err
figure(73)

% histogram
n=[];
for jx=1:length(labels)
    [n(jx,:),x] = hist(rate(jx).d,[0.05:0.1:2]);
end

subplot(1,2,1)
hb=bar(x,n','EdgeColor','none');
for jx = 1:length(hb)
    hb(jx).FaceColor = cmap(jx,:);
end
set(gca,'fontsize',16,'xtick',[0 0.2 0.4 0.6 0.8 1])
xlim([0 1])
xlabel('Rate (stalls / min)')
title('Histogram')
grid on
legend(labels,'location','best')

% normalized cumulative sum
n=[];
nCumsum = [];
for jx = 1:length(labels)
    for ix = 1:length(mice)
        [n(ix,:,jx),x] = hist(rateFile(ix,jx).d,[0.05:0.1:2]);
        n(ix,:,jx) = n(ix,:,jx) / length(rateFile(ix,jx).d);
        nCumsum(ix,:,jx) = cumsum(n(ix,:,jx));
    end
end
nCumsumMean = squeeze(mean(nCumsum,1));
nCumsumStdErr = squeeze(std(nCumsum,[],1) / sqrt(length(mice)));

subplot(1,2,2)
hold on
for jx = 1:length(labels)
    er = errorbar(x,nCumsumMean(:,jx),-nCumsumStdErr(:,jx),+nCumsumStdErr(:,jx),'.');    
    er.Color = cmap(jx,:);                            
    er.LineStyle = 'none';
    h=plot(x,nCumsumMean(:,jx),'.','markersize',16,'Color',cmap(jx,:));
end
xlabel('Rate (stalls / min)')
title('Norm. Cum. Sum')
grid on
set(gca,'fontsize',16)

%%
pause(1)
f = figure(72);
f.Position = [100 100 800 300];
f = figure(73);
f.Position = [100 100 800 300];
