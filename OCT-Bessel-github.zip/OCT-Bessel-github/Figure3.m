%% OCT Bessel Stalls - Figure 3
clearvars;
close all;

%% Load OCT data and calculate distributions
o.rate = [];
o.avgduration = [];

dataDir = fullfile(pwd,'Data\OCT_Stallograms\');
dataFiles = dir([dataDir '\*.mat']);
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));
    
    nstalls = sum(diff([zeros(size(StallingMatrix,1),1) StallingMatrix],1,2) == 1,2);
    avgdurstalls = zeros(size(StallingMatrix,1),1);
    for jx = 1:size(StallingMatrix,1)
        durstalls = find(diff([0 StallingMatrix(jx,:) 0]) == -1) - find(diff([0 StallingMatrix(jx,:) 0]) == 1);
        avgdurstalls(jx) = mean(durstalls);
    end
    ratedist = nstalls / 20; % rate per minute (20 minutes total)
    o.rate = [o.rate; ratedist]; 

    [o.n(ix,:),x] = hist(ratedist,[0.025:0.05:2]);
    o.nnorm(ix,:) = o.n(ix,:) / length(nstalls);
    o.nCumsum(ix,:) = cumsum(o.nnorm(ix,:));
end

%% Load Bessel data and calculate distributions
b.rate = [];
b.avgduration = [];

dataDir = fullfile(pwd,'Data\Bessel_Stallograms\');
dataFiles = dir([dataDir '\*.mat']);
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));

    % Exclude plasma-only stalls
    GTStallingMatrix(GTStallingMatrix == 2) = 0;
    GTStallingMatrix = GTStallingMatrix > 0;
    StallingMatrix = GTStallingMatrix(sum(GTStallingMatrix,2) > 0,:);

    nstalls = sum(diff([zeros(size(StallingMatrix,1),1) StallingMatrix],1,2) == 1,2);
    avgdurstalls = zeros(size(StallingMatrix,1),1);
    for jx = 1:size(StallingMatrix,1)
        durstalls = find(diff([0 StallingMatrix(jx,:) 0]) == -1) - find(diff([0 StallingMatrix(jx,:) 0]) == 1);
        avgdurstalls(jx) = mean(durstalls);
    end
    ratedist = nstalls / 20; % rate per minute (20 minutes total)
    b.rate = [b.rate; ratedist]; 
    [b.n(ix,:),x] = hist(ratedist,[0.025:0.05:2]);
    b.nnorm(ix,:) = b.n(ix,:) / length(nstalls);
    b.nCumsum(ix,:) = cumsum(b.nnorm(ix,:));
end

%% OCT cumsum plot
nMean = squeeze(mean(o.n,1));
nStdErr = squeeze(std(o.n,[],1)) / sqrt(size(o.n,1));

nCumsumMean = squeeze(mean(o.nCumsum,1));
nCumsumStdErr = squeeze(std(o.nCumsum,[],1) / sqrt(size(o.n,1)));

figure(1)
subplot(1,2,2); hold on
h(1)=plot(x,nCumsumMean,'k.','markersize',16);

hold on
er = errorbar(x,nCumsumMean,-nCumsumStdErr,+nCumsumStdErr);
er.Color = 'k';
xlim([0 1])
er.LineStyle = 'none';  
er.LineWidth = 1.5;  
hold off
xlabel('Rate (stalls / min)')
title('Norm. Cum. Sum')
set(gca,'fontsize',16)

set(gcf,'color',[1 1 1])

o.nMean = nMean;

%% Bessel cumsum plot
nMean = squeeze(mean(b.n,1));
nStdErr = squeeze(std(b.n,[],1)) / sqrt(size(b.n,1));

nCumsumMean = squeeze(mean(b.nCumsum,1));
nCumsumStdErr = squeeze(std(b.nCumsum,[],1) / sqrt(size(b.n,1)));

subplot(1,2,2); hold on
h(2)=plot(x,nCumsumMean,'b.','markersize',16);

hold on
er = errorbar(x,nCumsumMean,-nCumsumStdErr,+nCumsumStdErr);
er.Color = 'b';
xlim([0 1])
er.LineStyle = 'none';  
er.LineWidth = 1.5;  
hold off
xlabel('Rate (stalls / min)')
title('Norm. Cum. Sum')
legend(h,'OCT','Bessel','Location','Best')
set(gca,'fontsize',16)
grid on
set(gcf,'color',[1 1 1])
ylim([0 1])

b.nMean = nMean;

%% Histogram
subplot(1,2,1); hold on
hb=bar(x,[sum(o.n,1); sum(b.n,1)],'EdgeColor','none');
hb(1).FaceColor = 'k';
hb(2).FaceColor = 'b';
xlim([0 1])
xlabel('Rate (stalls / min)')
title('Histogram')
legend('OCT','Bessel','Location','Best')
set(gca,'fontsize',16)
grid on

f = figure(1);
f.Position = [100 100 1100 500];
