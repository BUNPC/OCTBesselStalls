%% OCT Bessel Stalls - Figure 5
clearvars;
close all;

cmap = [0 0 0; 0 0 1; 0.4 0.4 0.4]; % colormap

%% Plot 1
data1 = [67.34 46.48; 46.92 38.62]; % means
err1 = [10.32 11.36; 14.28 6.88]; % corrected stdev
ss1 = [12 4; 12 4]; % number datasets
groupwidth = min(0.8, size(data1,2)/(size(data1,2) + 1.5));

figure
subplot(1,3,1)
b = bar(data1,'grouped');
hold on
[ngroups,nbars] = size(data1);
x = nan(nbars, ngroups);
for ix = 1:nbars
    x(ix,:) = b(ix).XEndPoints;
end
for ix = 1:size(data1,2)
    b(ix).EdgeColor = cmap(ix,:);
    b(ix).FaceColor = cmap(ix,:);
    b(ix).FaceAlpha = 0.8;
    b(ix).LineWidth = 2;
end
errorbar([x(:)],[data1(:)],[err1(:)]./sqrt([ss1(:)]),'k.','LineWidth',2)
for ix = 1:numel(x)
    h = text(x(ix),data1(ix)/20,[num2str(data1(ix),3) '%, n=' num2str(ss1(ix))]);
    set(h,'Rotation',90);
end
ylabel('Common Stalling Capillaries (%)')
title('10-Minute Recording')
legend('OCT','Bessel')
xticklabels({'Consecutive','1 Week'})
ylim([0 100])
set(findall(gcf,'-property','FontSize'),'FontSize',16)

%%
data2 = [53.61; 48.65; 34.88]; % means
err2 = [8.6; 6.22; 9.88]; % corrected stdev
ss2 = [4; 4; 12]; % pairs of datasets
groupwidth = min(0.8, size(data2,2)/(size(data2,2) + 1.5));

subplot(1,2,2)
hold on
for ix = 1:length(data2)
    b(ix) = bar(ix/2,data2(ix),0.3);
    b(ix).EdgeColor = cmap(ix,:);
    b(ix).FaceColor = cmap(ix,:);
    b(ix).FaceAlpha = 0.8;
    b(ix).LineWidth = 2;
end
errorbar((1:length(data2))/2,data2,err2 ./ sqrt(ss2),'k.','LineWidth',2)
for ix = 1:length(data2)
    h = text(ix/2,data2(ix)/20,[num2str(data2(ix),3) '%, n=' num2str(ss2(ix))]);
    set(h,'Rotation',90);
end
ylabel('Common Stalling Capillaries (%)')
title('20-Minute Recording')
xticks((1:length(data2))/2)
xticklabels({'OCT 1-Wk','Bessel 1-Wk','OCT-Bessel'})
ylim([0 100])
set(findall(gcf,'-property','FontSize'),'FontSize',16)

%% Format axes
subplot(1,3,1)
ax = gca;
ax.XAxis.FontSize = 12;
subplot(1,2,2)
ax = gca;
ax.XAxis.FontSize = 12;
xlim([-0.5 2.5])
