%% OCT Bessel Stalls - Figure 4
clearvars;
close all;

%% Load OCT and Bessel data
dataDir = fullfile(pwd,'Data\OCT_Stallograms\');
dataFiles = dir([dataDir '\*.mat']);
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));
    odata{ix} = StallingMatrix;
end

dataDir = fullfile(pwd,'Data\Bessel_Stallograms\');
dataFiles = dir([dataDir '\*.mat']);
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));
    GTStallingMatrix(GTStallingMatrix == 2) = 0;
    GTStallingMatrix = GTStallingMatrix > 0;
    StallingMatrix = GTStallingMatrix(sum(GTStallingMatrix,2) > 0,:);
    bdata{ix} = StallingMatrix;
end

%% Calculate stats
o = calc_stats(odata,'o');
o.durMean = squeeze(mean(o.durHist,1));
o.durStdErr = squeeze(std(o.durHist,[],1)) / sqrt(size(o.durHist,1));
o.durCumsumMean = squeeze(mean(o.durCumsum,1));
o.durCumsumStdErr = squeeze(std(o.durCumsum,[],1) / sqrt(size(o.durHist,1)));
o.durCumsumMedian = squeeze(median(o.durCumsum,1));
o.durCumsumPrctile = squeeze(prctile(o.durCumsum,[5 95],1));
o.durCumsumAll = cumsum(o.durHistNormAll);

b = calc_stats(bdata,'b');
b.durMean = squeeze(mean(b.durHist,1));
b.durStdErr = squeeze(std(b.durHist,[],1)) / sqrt(size(b.durHist,1));
b.durCumsumMean = squeeze(mean(b.durCumsum,1));
b.durCumsumStdErr = squeeze(std(b.durCumsum,[],1) / sqrt(size(b.durHist,1)));
b.durCumsumAll = cumsum(b.durHistNormAll);

%% Group bins
bcb = [0.875:1.75:240]; % Bessel bin centers
bco = [3.75:7.5:240]; % OCT bin centers
bwo = [7.5:7.5:240]; % OCT bin edges

% assign Bessel bins to OCT bins
ixs = zeros(size(bcb));
for ix = 1:length(bcb)
    ixs(ix) = sum(bcb(ix) > bwo);
end
ixs = ixs + 1;

% group Bessel bins
[~,f] = mode(ixs);
nbix = zeros(max(ixs),f);
origix = 1:length(bcb);
for ix = 1:max(ixs)
    nbix(ix,1:sum(ixs == ix)) = origix(ixs == ix);
end

uixs = unique(ixs);
bcbnew = zeros(1,length(uixs));
for ix = 1:length(uixs)
    bcbnew(ix) = mean(bcb(ixs == uixs(ix)));
end

% for each file, group the data
b.durHistNew = zeros(size(b.durHist,1),max(ixs),f);
for iFile = 1:size(b.durHist,1)
    nb = b.durHist(iFile,:); nbstd = std(b.durHist(iFile,:),1); xb = b.x;
    no = o.durHist(iFile,:); nostd = std(o.durHist(iFile,:),1); xo = o.x;

    nbnew = zeros(max(ixs)*f,1);
    nbstdnew = zeros(max(ixs)*f,1);
    ixrepl = (reshape(nbix',1,[]) > 0) .* (1:numel(nbnew));
    ixrepl = ixrepl(ixrepl ~= 0);
    nbnew(ixrepl) = nb;
    nbstdnew(ixrepl) = nbstd;
    nbnew = reshape(nbnew,f,max(ixs))';
    nbstdnew = reshape(nbstdnew,f,max(ixs))';
    
    for ix = 1:size(nbnew,1)
        if nbnew(ix,1) == 0
            nbnew(ix,:) = circshift(nbnew(ix,:),size(nbnew,2) - 1);
            nbstdnew(ix,:) = circshift(nbstdnew(ix,:),size(nbstdnew,2) - 1);
        end
    end
    b.durHistNew(iFile,:,:) = nbnew;
    b.durHistNormNew(iFile,:,:) = nbnew / sum(nbnew,'all');
    b.durStdNew(iFile,:,:) = nbstdnew;
end
b.durCumsumNew = cumsum(sum(b.durHistNormNew,3),2);

% for each file, group the All data
nb = b.durHistAll; xb = b.x;
no = o.durHistAll; xo = o.x;

nbnew = zeros(max(ixs)*f,1);
ixrepl = (reshape(nbix',1,[]) > 0) .* (1:numel(nbnew));
ixrepl = ixrepl(ixrepl ~= 0);
nbnew(ixrepl) = nb;
nbnew = reshape(nbnew,f,max(ixs))';

for ix = 1:size(nbnew,1)
    if nbnew(ix,1) == 0
        nbnew(ix,:) = circshift(nbnew(ix,:),size(nbnew,2) - 1);
    end
end
b.durHistAllNew = nbnew;
b.durHistNormAllNew = nbnew / sum(nbnew,'all');
b.durCumsumAllNew = cumsum(sum(b.durHistNormAllNew,2));
b.durMeanNew = squeeze(mean(sum(b.durHistNew,3),1));
b.durStdErrNew = squeeze(std(sum(b.durHistNew,3),[],1)) / sqrt(size(b.durHistNew,1));
b.durCumsumMeanNew = squeeze(mean(sum(b.durCumsumNew,3),1));
b.durCumsumStdErrNew = squeeze(std(sum(b.durCumsumNew,3),[],1) / sqrt(size(b.durHist,1)));

%% Plot histogram
figure(51)
subplot(1,2,1); hold on
cmap = parula(6);
cmap(:,1:2) = cmap(:,1:2)*0.8;
hb=bar(bco,b.durHistAllNew,0.6,'stacked');
for ix = 1:length(hb)
    hb(ix).FaceAlpha = 0.8;
    hb(ix).FaceColor = cmap(ix,:);
    hb(ix).EdgeColor = 'none';
end
hb=bar(bco,o.durHistAll,0.05);
hb.FaceAlpha = 1;
hb.FaceColor = 'k';
hb.EdgeColor = 'k';
errorbar(bco,o.durHistAll,3*ones(size(bco)),'k.','horizontal','CapSize',0,'LineWidth',2)

xlim([0 60])
set(gca,'fontsize',16)
title('Histogram')
xlabel('Duration (seconds)')
legend('Bessel','C','D','E','F','OCT')
grid on

%% Plot cumsum
subplot(1,2,2); hold on
plot(bco,b.durCumsumAllNew,'.','markersize',16,'color','b')
plot(bco,o.durCumsumAll,'.','markersize',16,'color','k')
errorbar(bco,b.durCumsumAllNew,b.durCumsumStdErrNew,'b.','LineWidth',2);
errorbar(bco,o.durCumsumAll,o.durCumsumStdErr,'k.','LineWidth',2);

hold off
xlim([0 60])
set(gca,'fontsize',16)
title('Norm. Cum. Sum')
xlabel('Duration (seconds)')
set(gca,'xgrid','on','ygrid','on','xminortick','on')
legend('Bessel','OCT','Location','Best')
ylim([0.5 1])
set(gcf,'color',[1 1 1])

f = figure(51);
f.Position = [100 100 1100 500];

%% FUNCTIONS
function data = calc_stats(d,dtype)
    data = struct;

    nFiles = length(d);
    switch dtype
        case 'o'
            tPerFrame = 7.5;
            bins = [3.75:7.5:240];
        case 'b'
            tPerFrame = 1.75;
            bins = [0.875:1.75:240];
    end
    
    rate = [];
    durMean = [];
    durStd = [];
    cumIncidence = [];
    rateFile = [];
    durationFile = [];
    iCap1 = [];
    stallInterval = [];
    stallDuration = [];
    stallIntervalFR = [];
    stallDurationFR = [];
    stallIntervalSR = [];
    stallDurationSR = [];
    for iFile = 1:nFiles
        if iFile==1
            stallInterval = [];
            stallDuration = [];
            stallIntervalFR = [];
            stallDurationFR = [];
            stallIntervalSR = [];
            stallDurationSR = [];

            iCap1 = 0;
            rate = [];
        end
        rateFile(iFile).d = [];
        durationFile(iFile).d = {};
        iCapFile = 0;

        StallingMatrix = d{iFile};
        nCaps = size(StallingMatrix,1);
        nFrames = size(StallingMatrix,2);
        cumIncidenceMatrix = StallingMatrix;

        for iCap = 1:nCaps
            iRise = find(diff([0 StallingMatrix(iCap,:)])==1)';
            iFall = find(diff([StallingMatrix(iCap,:) 0])==-1)' + 1;
            durStall = (iFall - iRise) * tPerFrame;
            stallInterval = [stallInterval; (iRise(2:end)-iFall(1:(end-1)))*tPerFrame];
            stallDuration = [stallDuration; durStall];

            if ~isempty(iRise)
                cumIncidenceMatrix(iCap,iRise(1):end) = 1;

                iCap1 = iCap1 + 1;
                rate(iCap1,1) = length(iRise) * 60 / (nFrames * tPerFrame);
                durMean(iCap1,1) = mean(durStall);
                durStd(iCap1,1) = std(durStall);

                iCapFile = iCapFile + 1;
                rateFile(iFile).d(iCapFile) = length(iRise) * 60 / (nFrames * tPerFrame);
                durationFile(iFile).d{iCapFile} = durStall;

                if rate(iCap1)>=0.3
                    stallIntervalFR = [stallIntervalFR; (iRise(2:end)-iFall(1:(end-1)))*tPerFrame];
                    stallDurationFR = [stallDurationFR; durStall];
                elseif rate(iCap1)<=0.1
                    stallIntervalSR = [stallIntervalSR; (iRise(2:end)-iFall(1:(end-1)))*tPerFrame];
                    stallDurationSR = [stallDurationSR; durStall];
                end
            end
        end
        
        data.dur{iFile} = vertcat(durationFile(iFile).d{:});
        data.cumIncidence(:,iFile) = sum(cumIncidenceMatrix,1)';
        data.durHist(iFile,:) = hist(data.dur{iFile},bins);
        data.durHistNorm(iFile,:) = hist(data.dur{iFile},bins) / length(data.dur{iFile});
        data.durCumsum(iFile,:) = cumsum(data.durHistNorm(iFile,:));
    end

    data.stallInterval = stallInterval;
    data.stallDuration = stallDuration;
    data.stallIntervalFR = stallIntervalFR;
    data.stallDurationFR = stallDurationFR;
    data.stallIntervalSR = stallIntervalSR;
    data.stallDurationSR = stallDurationSR;
    [data.durHistAll,data.x] = hist(data.stallDuration,bins);
    data.durHistNormAll = data.durHistAll / sum(data.durHistAll,'all');
end