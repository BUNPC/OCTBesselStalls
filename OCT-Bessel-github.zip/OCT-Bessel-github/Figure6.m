%% OCT Bessel Stalls - Figure 6
clearvars;
close all;

%% Load data
b = load(fullfile(pwd,'Data\BesselRepeatRate_NoPlasma.mat'));
o = load(fullfile(pwd,'Data\OCTRepeatRate.mat'));

%% Plot
figure(10)

subplot(2,2,1)
img = o.hAll; 
img(find(img == 0)) = 1e-9;
img(1) = 1;
imagesc(0:size(img,1)-1,0:size(img,2)-1,log(img),[-0.1 4]);
cm = jet(1000); cm(1,:) = ones(1,1)*[1 1 1];
colormap(cm)
hc1=colorbar();
ylabel(hc1,'ln(Count)','Rotation',270)
hc1.Label.Position(1) = 3.5;
set(gca,'ydir','normal')
xlabel('# Stalls (first 10 min)')
ylabel('# Stalls (second 10 min)')
axis image
axis([-0.5 15.5 -0.5 15.5])
set(gca,'fontsize',16)
set(gca,'xgrid','on')
set(gca,'ygrid','on')
title('OCT')

subplot(2,2,2)
img = b.hAll; 
img(find(img == 0)) = 1e-9;
imagesc(0:size(img,1)-1,0:size(img,2)-1,log(b.hAll),[-0.1 4]);
hc2=colorbar();
ylabel(hc2,'ln(Count)','Rotation',270)
hc2.Label.Position(1) = 3.5;
set(gca,'ydir','normal')
xlabel('# Stalls (first 10 min)')
ylabel('# Stalls (second 10 min)')
axis image
axis([-0.5 15.5 -0.5 15.5])
set(gca,'fontsize',16)
set(gca,'xgrid','on')
set(gca,'ygrid','on')
title('Bessel')

figure(10)
subplot(2,2,3)
h(1)=plot(1:length(o.nCapAll),mean(o.nCapRepeatAll,1)./o.nCapAll,'k.-');
hold on
h(2)=plot(1:length(o.nCapAll),mean(b.nCapRepeatAll,1)./b.nCapAll,'b.-');
hold off
xlim([0.9 length(o.nCapAll)+0.1])
ylim([-0.05 1.05])
xlabel('# Stalls in 10 min')
ylabel('% Repeat Stalls')
set(gca,'fontsize',16)
grid on
colorbar()
legend('OCT','Bessel','location','best')
set(h,'linewidth',2)
set(h,'markersize',24)

subplot(2,2,4)
h(1)=plot(1:length(o.nCapAll),o.nCapAll./o.nStalls,'k.-');
hold on
h(2)=plot(1:length(b.nCapAll),b.nCapAll./b.nStalls,'b.-');
hold off
xlim([0.9 length(o.nCapAll)+0.1])
ylim([-0.05 1.05])
xlabel('# Stalls in 10 min')
ylabel('% Caps with Rate >= x')
set(gca,'fontsize',16)
grid on
colorbar()
set(h,'linewidth',2)
set(h,'markersize',24)

f = figure(10);
set(f,"Position",[100 100 1000 800])