10 min OCT data collected in stroke animals

Timepoints:
BL - Baseline (pre-stroke)
D2 - Day 2
W1 - Week 1
W2 - Week 2
W4 - Week 4

Data structure:
StallingMatrix - (# stalling capillaries) x (80 frames), 
	0 if not stalled, 
	1 if stalled, 