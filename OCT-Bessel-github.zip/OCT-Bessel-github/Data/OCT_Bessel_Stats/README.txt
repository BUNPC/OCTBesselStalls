Mouse#_Timepoint_OCT_Stats = OCT stats
Mouse#_Timepoint_Bessel_Stats = Bessel stats EXCLUDING plasma-only stalls
Mouse#_Timepoint_Bessel_Stats_w_Plasma = Bessel stats INCLUDING plasma-only stalls

Timepoint 2 is 1 week after Timepoint 1

Female - Mouse001, Mouse002, Mouse003
Male - Mouse004, Mouse005, Mouse006, Mouse007

Data structure:
allDurations - cell (length n stalling capillaries) with the duration in # of frames for each stall in that capillary
cumulat - cumulative stall duration averaged over capillaries
incCurve_all - cumulative incidence curve
incid - incidence of stalls
prev - prevalence of stalls averaged over time
stallMat (Bessel only) - the StallingMatrix with only stalling capillaries
stallPts (Bessel only) - StallingMatrix with non-stalling capillaries included
total (Bessel only) - total number of capillaries in FOV
num_stall (OCT only) - number of stalling capillaries
