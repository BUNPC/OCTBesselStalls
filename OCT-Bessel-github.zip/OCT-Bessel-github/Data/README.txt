Folders:
Bessel_Stallograms - contains Bessel stall-o-grams
OCT_Bessel_Stats - contains stats for OCT and Bessel such as incidence, prevalence, cumulative duration and cumulative incidence
OCT_Stallograms - contains OCT stall-o-grams
Stroke_OCT_Stallograms - contains OCT stall-o-grams from stroke datasets
Supplementary - contains the 1hr OCT measurement for the supplementary figures

Files:
BesselRepeatRate_NoPlasma.mat - Bessel repeatability statistics EXCLUDING plasma-only stalls
OCTRepeatRate.mat - OCT repeatability statistics

Data structure:
hAll - histogram of number of stalls with 1-16 stalls in the first 10 min (rows) and second 10 min (columns) of 20-minute recordings
nCapAll - number of capillaries with at least 1-4 stalls in either period of 10 min
	total # in hAll - # in hAll(1:x,1:x) [i.e. hAll(1,1), hAll(1:2,1:2), hAll(1:3,1:3), or hAll(1:4,1:4)]
nCapRepeatAll - number of capillaries with at least 1-4 stalls in both periods of 10 min
	total # in hAll - # in hAll(1:x,1:x) - # in hAll((x+1):16,1) - # in hAll(1,(x+1):16)
nStalls - total # in hAll


