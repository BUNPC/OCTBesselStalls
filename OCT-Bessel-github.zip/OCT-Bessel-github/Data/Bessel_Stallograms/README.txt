Mouse#_Timepoint_OCT = OCT stallogram
Mouse#_Timepoint_Bessel = Bessel stallogram 

Timepoint 2 is 1 week after Timepoint 1

Female - Mouse001, Mouse002, Mouse003
Male - Mouse004, Mouse005, Mouse006, Mouse007

Data structure:
GTStallingMatrix - (total # capillaries) x (700 frames), 
	0 if not stalled, 
	1 if conventional stall, 
	2 if plasma-only stall