%% OCT Bessel Stalls - Figure 2
clearvars;
close all;

%% Load OCT incidence curve data and calculate time to first stall
o = [];

dataDir = fullfile(pwd,'Data\OCT_Bessel_Stats\');
dataFiles = dir([dataDir '\*OCT*.mat']);
ostall_times = cell(1,length(dataFiles));
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));
    o = [o; incCurve];                              % all incidence curves
    
    % Find time to first stall
    do = diff(incCurve);
    do = round(incCurve / min(do(do>0)));
    ddo = diff([0 do]);
    for jx = 1:length(ddo)
        for kx = 1:ddo(jx)
            ostall_times{ix} = [ostall_times{ix}; jx * 7.5/60]; % time to first stall
        end
    end
end

%% Fit the incidence curve
t = (0:size(o,2)-1) / 8; % Time vector with 7.5s frame rate (8/min)

% double exp fit
doubleexp = fittype('A*(1 - exp(-x/B)) + C*(1 - exp(-x/D)) + E', 'independent', 'x', 'coefficients', {'A', 'B', 'C','D','E'});
w = 1./std(o,1).^2; % calculate weights for fit   
if exist('w','var') % if std var included in input, use it for weights in fit model        
    doexpFitModel = fit(t', mean(o,1)', doubleexp, 'Start', [1 10 1 90 1], 'Lower', [0 0 0 0 0], 'Upper', [100 Inf 100 Inf 100], 'Weights', w);    
else        
    doexpFitModel = fit(t', mean(o,1)', doubleexp, 'Start', [1 10 1 90 1], 'Lower', [0 0 0 0 0], 'Upper', [100 Inf 100 Inf 100]);    
end    
doubleexpfit = feval(doexpFitModel, t);

% single exp fit
singleexp = fittype('A*(1 - exp(-x/B)) + C', 'independent', 'x', 'coefficients', {'A', 'B', 'C'}); 
w = 1./std(o,1).^2; % calculate weights for fit   
if exist('w','var') % if std var included in input, use it for weights in fit model        
    soexpFitModel = fit(t', mean(o,1)', singleexp, 'Start', [1 10 1], 'Lower', [0 0 0], 'Upper', [100 Inf 100], 'Weights', w);    
else        
    soexpFitModel = fit(t', mean(o,1)', singleexp, 'Start', [1 10 1], 'Lower', [0 0 0], 'Upper', [100 Inf 100]);    
end    
singleexpfit = feval(soexpFitModel, t);

% Plot
figure
plot(t, mean(o,1), 'k', 'LineWidth', 3)
hold on
fill([t, fliplr(t)], [mean(o,1) + std(o,[],1), fliplr(mean(o,1) - std(o,[],1))], [0.3 0.3 0.3], 'FaceAlpha',0.2, 'EdgeColor', 'none');
plot(t,doubleexpfit,':','Color','b','LineWidth',3)
plot(t,singleexpfit,':','Color','r','LineWidth',3)
ylim([0 25])
ylabel('Stall Incidence (%)')
xlim([0 20])
xlabel('Time (minutes)')
title('OCT Cumulative Incidence')
legend('Mean Incidence','STDev','Double Exponential Fit','Single Exponential Fit')
set(findall(gcf,'-property','FontSize'),'FontSize',16)

r1 = corrcoef(mean(o,1),doubleexpfit);
r1 = r1(2)^2;
r2 = corrcoef(mean(o,1),singleexpfit);
r2 = r2(2)^2;

%% Load Bessel incidence curve data and calculate time to first stall
b = [];

dataDir = fullfile(pwd,'Data\OCT_Bessel_Stats\');
dataFiles = dir([dataDir '\*Bessel*.mat']);
dataFiles = dataFiles(~contains({dataFiles.name},'Plasma'));
bstall_times = cell(1,length(dataFiles));
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));
    b = [b; incCurve_all];                          % all incidence curves

    % Find time to first stall
    db = diff(incCurve_all);
    db = round(incCurve_all / min(db(db>0)));
    ddb = diff([0 db]);
    for jx = 1:length(ddb)
        for kx = 1:ddb(jx)
            bstall_times{ix} = [bstall_times{ix}; jx * 1.75/60]; % time to first stall
        end
    end
end

%% Fit the incidence curve
t = (0:size(b,2)-1) / 35;

% double exp fit
doubleexp = fittype('A*(1 - exp(-x/B)) + C*(1 - exp(-x/D)) + E', 'independent', 'x', 'coefficients', {'A', 'B', 'C','D','E'});
w = 1./std(b,1).^2; % calc weights for fit   
if exist('w','var') % if std var included in input, use it for weights in fit model        
    dbexpFitModel = fit(t', mean(b,1)', doubleexp, 'Start', [1 10 1 90 1], 'Lower', [0 0 0 0 0], 'Upper', [100 Inf 100 Inf 100], 'Weights', w);    
else        
    dbexpFitModel = fit(t', mean(b,1)', doubleexp, 'Start', [1 10 1 90 1], 'Lower', [0 0 0 0 0], 'Upper', [100 Inf 100 Inf 100]);    
end    
doubleexpfit = feval(dbexpFitModel, t);

% single exp fit
singleexp = fittype('A*(1 - exp(-x/B)) + C', 'independent', 'x', 'coefficients', {'A', 'B', 'C'}); 
w = 1./std(b,1).^2; % calc weights for fit   
if exist('w','var') % if std var included in input, use it for weights in fit model        
    sbexpFitModel = fit(t', mean(b,1)', singleexp, 'Start', [1 10 1], 'Lower', [0 0 0], 'Upper', [100 Inf 100], 'Weights', w);    
else        
    sbexpFitModel = fit(t', mean(b,1)', singleexp, 'Start', [1 10 1], 'Lower', [0 0 0], 'Upper', [100 Inf 100]);    
end    
singleexpfit = feval(sbexpFitModel, t);

% Plot
figure
plot(t, mean(b,1), 'k', 'LineWidth', 3)
hold on
fill([t, fliplr(t)], [mean(b,1) + std(b,[],1), fliplr(mean(b,1) - std(b,[],1))], [0.3 0.3 0.3], 'FaceAlpha',0.2, 'EdgeColor', 'none');
plot(t,doubleexpfit,':','Color','b','LineWidth',3)
plot(t,singleexpfit,':','Color','r','LineWidth',3)
ylim([0 25])
ylabel('Stall Incidence (%)')
xlim([0 20])
xlabel('Time (minutes)')
title('Bessel Cumulative Incidence')
legend('Mean Incidence','STDev','Double Exponential Fit','Single Exponential Fit')
set(findall(gcf,'-property','FontSize'),'FontSize',16)

r3 = corrcoef(mean(b,1),doubleexpfit);
r3 = r3(2)^2;
r4 = corrcoef(mean(b,1),singleexpfit);
r4 = r4(2)^2;
