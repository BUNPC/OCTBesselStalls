%% OCT Bessel Stalls - Supplementary Figures
clearvars;
close all;

%% Supplementary figure 1
load(fullfile(pwd,'Data\Supplementary\Mouse002_1hr_OCT.mat'))
trace = sum((cumsum(diff([zeros(size(StallingMatrix,1),1) StallingMatrix],1,2) == 1,2) > 0),1) / 151 * 100;
t = (0:length(trace)-1) / 8;
doubleexp = fittype('A*(1 - exp(-x/B)) + C*(1 - exp(-x/D)) + E', 'independent', 'x', 'coefficients', {'A', 'B', 'C', 'D', 'E'}); 
doubleexpfit = fit(t',trace',doubleexp,'StartPoint',[1 10 1 90 1],'lower',[0 0 0 0 0],'upper',[100 Inf 100 Inf 100]);

f = figure(101);
plot(t,trace,'k-','LineWidth',3)
hold on
plot(t,feval(doubleexpfit,t),':','Color','b','LineWidth',3)
title('1-hour OCT')
ylabel('Stall Incidence (%)')
xlabel('Time (minutes)')
legend('Cumulative Incidence','Exponential Fit')
set(findall(gcf,'-property','FontSize'),'FontSize',16)

%% Supplementary figure 2
cmap = [0 0 1; 0 0 0; 0.4 0.4 0.4];

% OCT
dataDir = fullfile(pwd,'Data\OCT_Stallograms\');
dataFiles = dir([dataDir '\*.mat']);
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));
    odata{ix} = StallingMatrix;
end

nFiles = length(odata);
tPerFrame = 7.5;
bins = [3.75:7.5:240];
stallRateMean = [];
stallDurationMean = [];
for iFile = 1:nFiles
    StallingMatrix = odata{iFile};
    nCaps = size(StallingMatrix,1);
    nFrames = size(StallingMatrix,2);
    for iCap = 1:nCaps
        iRise = find(diff([0 StallingMatrix(iCap,:)])==1)';
        iFall = find(diff([StallingMatrix(iCap,:) 0])==-1)' + 1;
        durStall = (iFall - iRise) * tPerFrame;
        stallRateMean = [stallRateMean; length(iRise) * 60 / (nFrames * tPerFrame)];
        stallDurationMean = [stallDurationMean; mean(durStall)];
    end
end
o.stallRateMean = stallRateMean;
o.stallDurationMean = stallDurationMean;

% Bessel
dataDir = fullfile(pwd,'Data\Bessel_Stallograms\');
dataFiles = dir([dataDir '\*.mat']);
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));
    GTStallingMatrix(GTStallingMatrix == 2) = 0;
    GTStallingMatrix = GTStallingMatrix > 0;
    StallingMatrix = GTStallingMatrix(sum(GTStallingMatrix,2) > 0,:);
    bdata{ix} = StallingMatrix;
end

nFiles = length(bdata);
tPerFrame = 1.75;
bins = [0.875:1.75:240];
stallRateMean = [];
stallDurationMean = [];
for iFile = 1:nFiles
    StallingMatrix = bdata{iFile};
    nCaps = size(StallingMatrix,1);
    nFrames = size(StallingMatrix,2);
    for iCap = 1:nCaps
        iRise = find(diff([0 StallingMatrix(iCap,:)])==1)';
        iFall = find(diff([StallingMatrix(iCap,:) 0])==-1)' + 1;
        durStall = (iFall - iRise) * tPerFrame;
        stallRateMean = [stallRateMean; length(iRise) * 60 / (nFrames * tPerFrame)];
        stallDurationMean = [stallDurationMean; mean(durStall)];
    end
end
b.stallRateMean = stallRateMean;
b.stallDurationMean = stallDurationMean;

figure(102)
hold on
scatter(b.stallRateMean,b.stallDurationMean,20,'filled','MarkerEdgeColor',cmap(1,:),'MarkerFaceColor',cmap(1,:))
scatter(o.stallRateMean,o.stallDurationMean,20,'filled','MarkerEdgeColor',cmap(2,:),'MarkerFaceColor',cmap(2,:))
ylim([0 60])
xlabel('Stall Rate (stalls/min)')
ylabel('Mean Duration (seconds)')
title('Stall Duration vs. Stall Rate')
legend('Bessel','OCT')
set(findall(gcf,'-property','FontSize'),'FontSize',16)

%% Supplementary figure 3
% OCT
dataDir = fullfile(pwd,'Data\OCT_Stallograms\');
dataFiles = dir([dataDir '\*.mat']);
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));
    
    nstalls = sum(diff([zeros(size(StallingMatrix,1),1) StallingMatrix],1,2) == 1,2);
    [o.n(ix,:),x] = hist(nstalls / 20,[0.025:0.05:2]);
    o.n(ix,:) = o.n(ix,:) / length(nstalls);
end
o.nMean = squeeze(mean(o.n,1));

% Bessel
dataDir = fullfile(pwd,'Data\Bessel_Stallograms\');
dataFiles = dir([dataDir '\*.mat']);
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));
    
    GTStallingMatrix(GTStallingMatrix == 2) = 0;
    GTStallingMatrix = GTStallingMatrix > 0;
    StallingMatrix = GTStallingMatrix(sum(GTStallingMatrix,2) > 0,:);
    nstalls = sum(diff([zeros(size(StallingMatrix,1),1) StallingMatrix],1,2) == 1,2);
    [b.n(ix,:),x] = hist(nstalls / 20,[0.025:0.05:2]);
    b.n(ix,:) = b.n(ix,:) / length(nstalls);
end
b.nMean = squeeze(mean(b.n,1));

figure(103)
hold on
hb=bar(x,[o.nMean; b.nMean],'EdgeColor','none');
pause(1)
hb(1).FaceColor = 'k';
hb(2).FaceColor = 'b';
xlim([0 1])
xlabel('Rate (stalls / min)')
title('Norm. Histogram')
legend('OCT','Bessel','Location','Best')
set(gca,'fontsize',16)
grid on

f = figure(103);
f.Position = [100 100 1000 500];

%% Supplementary figure 4
% OCT
dataDir = fullfile(pwd,'Data\OCT_Stallograms\');
dataFiles = dir([dataDir '\*.mat']);
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));
    odata{ix} = StallingMatrix;
end

nFiles = length(odata);
tPerFrame = 7.5;
bins = [3.75:7.5:240];
durMean = [];
durStd = [];
durationFile = [];
iCap1 = [];
stallDuration = [];
for iFile = 1:nFiles
    if iFile==1
        stallDuration = [];
        iCap1 = 0;
    end
    durationFile(iFile).d = {};
    iCapFile = 0;

    StallingMatrix = odata{iFile};
    nCaps = size(StallingMatrix,1);
    nFrames = size(StallingMatrix,2);
    for iCap = 1:nCaps
        iRise = find(diff([0 StallingMatrix(iCap,:)])==1)';
        iFall = find(diff([StallingMatrix(iCap,:) 0])==-1)' + 1;
        durStall = (iFall - iRise) * tPerFrame;
        stallDuration = [stallDuration; durStall];
        if ~isempty(iRise)
            iCap1 = iCap1 + 1;
            durMean(iCap1,1) = mean(durStall);
            durStd(iCap1,1) = std(durStall);
            iCapFile = iCapFile + 1;
            durationFile(iFile).d{iCapFile} = durStall;
        end
    end
    o.dur{iFile} = vertcat(durationFile(iFile).d{:});
    o.durHist(iFile,:) = hist(o.dur{iFile},bins) / length(o.dur{iFile});
end
o.stallDuration = stallDuration;
[o.durHistAll,o.x] = hist(o.stallDuration,bins);
o.durHistAll = o.durHistAll / sum(o.durHistAll,'all');

% Bessel
dataDir = fullfile(pwd,'Data\Bessel_Stallograms\');
dataFiles = dir([dataDir '\*.mat']);
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));
    GTStallingMatrix(GTStallingMatrix == 2) = 0;
    GTStallingMatrix = GTStallingMatrix > 0;
    StallingMatrix = GTStallingMatrix(sum(GTStallingMatrix,2) > 0,:);
    bdata{ix} = StallingMatrix;
end

nFiles = length(bdata);
tPerFrame = 1.75;
bins = [0.875:1.75:240];
durMean = [];
durStd = [];
durationFile = [];
iCap1 = [];
stallDuration = [];
for iFile = 1:nFiles
    if iFile==1
        stallDuration = [];
        iCap1 = 0;
    end
    durationFile(iFile).d = {};
    iCapFile = 0;

    StallingMatrix = bdata{iFile};
    nCaps = size(StallingMatrix,1);
    nFrames = size(StallingMatrix,2);
    for iCap = 1:nCaps
        iRise = find(diff([0 StallingMatrix(iCap,:)])==1)';
        iFall = find(diff([StallingMatrix(iCap,:) 0])==-1)' + 1;
        durStall = (iFall - iRise) * tPerFrame;
        stallDuration = [stallDuration; durStall];
        if ~isempty(iRise)
            iCap1 = iCap1 + 1;
            durMean(iCap1,1) = mean(durStall);
            durStd(iCap1,1) = std(durStall);
            iCapFile = iCapFile + 1;
            durationFile(iFile).d{iCapFile} = durStall;
        end
    end
    b.dur{iFile} = vertcat(durationFile(iFile).d{:});
    b.durHist(iFile,:) = hist(b.dur{iFile},bins) / length(b.dur{iFile});
end
b.stallDuration = stallDuration;
[b.durHistAll,b.x] = hist(b.stallDuration,bins);
b.durHistAll = b.durHistAll / sum(b.durHistAll,'all');

% Group bins
bcb = [0.875:1.75:240];
bco = [3.75:7.5:240];
bwo = [7.5:7.5:240];

% assign bessel bins to oct bins
ixs = zeros(size(bcb));
for ix = 1:length(bcb)
    ixs(ix) = sum(bcb(ix) > bwo);
end
ixs = ixs + 1;

% group bessel bins
[~,f] = mode(ixs);
nbix = zeros(max(ixs),f);
origix = 1:length(bcb);
for ix = 1:max(ixs)
    nbix(ix,1:sum(ixs == ix)) = origix(ixs == ix);
end

uixs = unique(ixs);
bcbnew = zeros(1,length(uixs));
for ix = 1:length(uixs)
    bcbnew(ix) = mean(bcb(ixs == uixs(ix)));
end

% for each file, group the data
b.durHistNew = zeros(size(b.durHist,1),max(ixs),f);
for iFile = 1:size(b.durHist,1)
    nb = b.durHist(iFile,:); xb = b.x;
    no = o.durHist(iFile,:); xo = o.x;

    nbnew = zeros(max(ixs)*f,1);
    ixrepl = (reshape(nbix',1,[]) > 0) .* (1:numel(nbnew));
    ixrepl = ixrepl(ixrepl ~= 0);
    nbnew(ixrepl) = nb;
    nbnew = reshape(nbnew,f,max(ixs))';
    
    for ix = 1:size(nbnew,1)
        if nbnew(ix,1) == 0
            nbnew(ix,:) = circshift(nbnew(ix,:),size(nbnew,2) - 1);
        end
    end
    b.durHistNew(iFile,:,:) = nbnew;
end

% for each file, group the All data
nb = b.durHistAll; xb = b.x;
no = o.durHistAll; xo = o.x;

nbnew = zeros(max(ixs)*f,1);
ixrepl = (reshape(nbix',1,[]) > 0) .* (1:numel(nbnew));
ixrepl = ixrepl(ixrepl ~= 0);
nbnew(ixrepl) = nb;
nbnew = reshape(nbnew,f,max(ixs))';
for ix = 1:size(nbnew,1)
    if nbnew(ix,1) == 0
        nbnew(ix,:) = circshift(nbnew(ix,:),size(nbnew,2) - 1);
    end
end
b.durHistAllNew = nbnew / sum(nbnew,'all');

figure(104)
hold on
cmap = parula(6);
cmap(:,1:2) = cmap(:,1:2)*0.8;
hb=bar(bco,b.durHistAllNew,0.6,'stacked');
for ix = 1:length(hb)
    hb(ix).FaceAlpha = 0.8;
    hb(ix).FaceColor = cmap(ix,:);
    hb(ix).EdgeColor = 'none';
end
hb=bar(bco,o.durHistAll,0.05);
hb.FaceAlpha = 1;
hb.FaceColor = 'k';
hb.EdgeColor = 'k';
errorbar(bco,o.durHistAll,3*ones(size(bco)),'k.','horizontal','CapSize',0,'LineWidth',2)

xlim([0 60])
ylim([0 1])
set(gca,'fontsize',16)
title('Norm. Histogram')
xlabel('Duration (seconds)')
legend('Bessel','C','D','E','F','OCT')
grid on

f = figure(104);
f.Position = [100 100 1100 500];

%% Supplementary figure 5
b = [];
dataDir = fullfile(pwd,'Data\OCT_Bessel_Stats\');
dataFiles = dir([dataDir '\*Bessel*.mat']);
dataFiles = dataFiles(~contains({dataFiles.name},'Plasma'));
bstall_times = cell(1,length(dataFiles));
for ix = 1:length(dataFiles)
    load(fullfile(dataFiles(ix).folder,dataFiles(ix).name));
    incCurve_all = incCurve_all(1:350);
    b = [b; incCurve_all];
    db = diff(incCurve_all);
    db = round(incCurve_all / min(db(db>0)));
    ddb = diff([0 db]);
    for jx = 1:length(ddb)
        for kx = 1:ddb(jx)
            bstall_times{ix} = [bstall_times{ix}; jx * 1.75/60];
        end
    end
end

t = (0:size(b,2)-1) / 35;

% double exp fit
doubleexp = fittype('A*(1 - exp(-x/B)) + C*(1 - exp(-x/D)) + E', 'independent', 'x', 'coefficients', {'A', 'B', 'C','D','E'});
w = 1./std(b,1).^2; % calc weights for fit   
if exist('w','var') % if std var included in input, use it for weights in fit model        
    dbexpFitModel = fit(t', mean(b,1)', doubleexp, 'Start', [1 10 1 90 1], 'Lower', [0 0 0 0 0], 'Upper', [100 Inf 100 Inf 100], 'Weights', w);    
else        
    dbexpFitModel = fit(t', mean(b,1)', doubleexp, 'Start', [1 10 1 90 1], 'Lower', [0 0 0 0 0], 'Upper', [100 Inf 100 Inf 100]);    
end    
doubleexpfit = feval(dbexpFitModel, t);

figure(105)
plot(t, mean(b,1), 'k', 'LineWidth', 3)
hold on
fill([t, fliplr(t)], [mean(b,1) + std(b,[],1), fliplr(mean(b,1) - std(b,[],1))], [0.3 0.3 0.3], 'FaceAlpha',0.2, 'EdgeColor', 'none');
plot(t,doubleexpfit,':','Color','b','LineWidth',3)

% single exp fit
singleexp = fittype('A*(1 - exp(-x/B)) + C', 'independent', 'x', 'coefficients', {'A', 'B', 'C'}); 
w = 1./std(b,1).^2; % calc weights for fit   
if exist('w','var') % if std var included in input, use it for weights in fit model        
    sbexpFitModel = fit(t', mean(b,1)', singleexp, 'Start', [1 10 1], 'Lower', [0 0 0], 'Upper', [100 Inf 100], 'Weights', w);    
else        
    sbexpFitModel = fit(t', mean(b,1)', singleexp, 'Start', [1 10 1], 'Lower', [0 0 0], 'Upper', [100 Inf 100]);    
end    
singleexpfit = feval(sbexpFitModel, t);

plot(t,singleexpfit,':','Color','r','LineWidth',3)

ylim([0 25])
ylabel('Stall Incidence (%)')
xlim([0 10])
xlabel('Time (minutes)')
title('Bessel Cumulative Incidence')
legend('Mean Incidence','STDev','Double Exponential Fit','Single Exponential Fit')
set(findall(gcf,'-property','FontSize'),'FontSize',16)

r3 = corrcoef(mean(b,1),doubleexpfit);
r3 = r3(2)^2;
r4 = corrcoef(mean(b,1),singleexpfit);
r4 = r4(2)^2;

%% Supplementary figure 6
t = 1:0.01:30;
yo = zeros(size(t));
yb = zeros(size(t));

for ix = 1:length(t)
    if t(ix) < 1.8
        yb(ix) = 0;
    else
        yb(ix) = ceil(t(ix)/1.8);
    end

    if t(ix) < 8
        yo(ix) = NaN;
    else
        yo(ix) = ceil(t(ix)/8);
    end
end

figure(106)
subplot(1,2,1)
hold on
a(1) = plot(t,yb,'b','LineWidth',2);
a(2) = plot(t,yo,'k','LineWidth',2);
plot(t(isnan(yo)),ones(1,sum(isnan(yo))),'k:','LineWidth',2)
xlim([min(t) max(t)])
xticks([1 10:10:max(t)])
xlabel('True Stall Duration')
ylabel('# of frames marked as stalled')
legend(a,'Bessel','OCT')

for ix = 1:length(t)
    if t(ix) < 1.8
        yb(ix) = 0;
    else
        yb(ix) = 0.875 + 1.75*floor(t(ix)/1.75);
    end

    if t(ix) < 8
        yo(ix) = NaN;
    else
        yo(ix) = 3.75 + 7.5*floor(t(ix)/7.5);
    end
end
ix = find(isnan(yo),1,'last');
yo(ix) = 3.75;

subplot(1,2,2)
hold on
a(1) = plot(t,yb,'b','LineWidth',2);
a(2) = plot(t,yo,'k','LineWidth',2);
plot(t(isnan(yo)),3.75*ones(1,sum(isnan(yo))),'k:','LineWidth',2)
a(3) = plot(t,t,'--','LineWidth',2,'Color','g');
xlim([min(t) max(t)])
xticks([1 10:10:max(t)])
xlabel('True Stall Duration')
ylabel('Nominal Stall Duration')
legend(a,'Bessel','OCT','Unity')

set(gcf,'Position',[20 20 1000 450])
set(findall(gcf,'-property','FontSize'),'FontSize',16)